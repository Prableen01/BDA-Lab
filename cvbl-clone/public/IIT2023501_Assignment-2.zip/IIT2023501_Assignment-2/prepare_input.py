import requests
from bs4 import BeautifulSoup

url = "https://en.wikipedia.org/wiki/Indian_Institute_of_Information_Technology,_Allahabad"
response = requests.get(url)
soup = BeautifulSoup(response.text, "html.parser")

text = soup.get_text(separator=" ")
words = text.split()[:1500]

with open("wiki_iiit_allahabad.txt", "w", encoding="utf-8") as f:
    f.write(" ".join(words))
